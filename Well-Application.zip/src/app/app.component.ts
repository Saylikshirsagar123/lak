import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent  {
  public lat = 18.510459;
  public long = 73.846541;

  constructor(){
  }

}
